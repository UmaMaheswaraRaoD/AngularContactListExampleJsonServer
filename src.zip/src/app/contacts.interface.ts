export interface contact {
    firstName: string;
    lastName: string;
    phone: string;
}