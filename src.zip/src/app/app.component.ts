import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ContactService } from './contact.service';
import { contact } from './contacts.interface';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  contactForm: FormGroup;
  contactList: contact[] = [];
  constructor(private formBuilder: FormBuilder, private service: ContactService) {
    this.createContactForm();
  }
  ngOnInit(): void {
    this.getContactsData();
  }

  createContactForm() {
    this.contactForm = this.formBuilder.group({
      firstName: [''],
      lastName: [''],
      phone: [''],
    });
  }
  getContactsData = () => {
    this.service.getContacts().subscribe(response => {
      this.contactList = response;
      console.log(this.contactList)
    });
  }

  onSubmit() {
    console.log('Your form data : ', this.contactForm.value);
    //  save the Form Data into Data Base 
    this.service.saveContact(this.contactForm.value).subscribe(response => {
      this.getContactsData();
    })
  }
  searchContact = (val: string) => {
    this.contactList = this.contactList.filter(item => item.firstName === val || item.lastName === val || item.phone === val);
    console.log(this.contactList)
  }
}
