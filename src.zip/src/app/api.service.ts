import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  constructor(private httpClient: HttpClient) { }

  serverUrl: string = 'http://128.137.69.38:9090/api/'


  getUser(url: string): Observable<any> {
    return this.httpClient.get(this.serverUrl + url);
  }
}
